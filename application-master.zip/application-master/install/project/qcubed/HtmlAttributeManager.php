<?php
namespace QCubed\Project;

/**
 * QHtmlAttributeManager
 *
 * The attribute manager gives you a general purpose way to set html attributes and css properties. This file
 * lets you create your own customizations of the core version of the file.
 *
 * @was QHtmlAttributeManager
 * @package QCubed\Project
 */
class HtmlAttributeManager extends \QCubed\HtmlAttributeManagerBase
{
}

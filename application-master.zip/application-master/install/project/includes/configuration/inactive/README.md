# The `inactive` directory

This is a convenience directory for you to place configuration files or other files
that you are temporarily not using. It is not used by QCubed.


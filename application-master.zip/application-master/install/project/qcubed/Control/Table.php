<?php

namespace QCubed\Project\Control;

/**
 * Class Table
 *
 * @was QHtmlTable
 * @package QCubed\Project\Control
 */
class Table extends \QCubed\Control\TableBase
{
}


<?php
/**
 * Part of the QCubed PHP framework.
 *
 * @license MIT
 *
 */

namespace QCubed\Exception;

/**
 * @was QCryptographyException
 */
class Cryptography extends Caller
{
}

<?php

namespace QCubed\Project\Control;

/**
 * The QJsTimer class (and related classes) reside here.
 *
 * @was QJsTimer
 * @package QCubed\Project\Control
 */
class JsTimer extends \QCubed\Control\JsTimerBase
{
}



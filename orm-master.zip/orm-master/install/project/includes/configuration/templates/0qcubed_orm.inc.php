<?php

// Called by the code generator to locate templates

$paths[] =  QCUBED_BASE_DIR . '/orm/codegen/templates/';
return $paths;
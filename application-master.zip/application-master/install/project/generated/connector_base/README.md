# About `connector_base` directory

Model connector base classes will be saved by the Code Generator here.

These files will be replaced every time you do a code generation.
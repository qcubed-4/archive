// The default is to redirect to the start page for development. Feel free to replace this index.php file with your own.

<?php
header('Location: vendor/qcubed-4/application/tools/start_page.php');

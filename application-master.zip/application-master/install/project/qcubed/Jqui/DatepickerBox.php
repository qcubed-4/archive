<?php
namespace QCubed\Project\Jqui;

use QCubed as Q;

/**
 * Class DatepickerBox
 *
 * This is the DatepickerBox class which was automatically generated
 * by scraping the JQuery UI documentation website. It overrides the DatepickerBoxBase
 * class, and provides you a way of inserting custom functionality into the control. Feel free
 * to make changes to this file.
 *
 * @see DatepickerBoxBase
 * @was QDatepickerBox
 */
class DatepickerBox extends Q\Jqui\DatepickerBoxBase
{
}

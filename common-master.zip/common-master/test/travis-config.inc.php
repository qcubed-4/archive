<?php

/**
 * The base configuration file for the travis test
 */
require ('./vendor/autoload.php');

define('QCUBED_ENCODING', 'UTF-8');

# About `fonts` directory

This directory contains fonts which are to be used by the QCubed framework itself. 

If you want to use custom fonts in your application, use the `fonts` directory located inside your project's assets directory.
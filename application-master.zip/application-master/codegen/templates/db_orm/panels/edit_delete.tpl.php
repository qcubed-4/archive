	public function delete() {
		$this->mct<?= $strPropertyName  ?>->delete<?= $strPropertyName ?>();
	}

	/** @var <?= $strPropertyName ?>EditPanel  */
	protected $pnl<?= $strPropertyName ?>;

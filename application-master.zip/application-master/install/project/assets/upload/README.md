# About `upload` directory

The directory for uploaded files. Should be writable.

Please remember that this directory is web-accessible by default. Do not put uploads here if you need to make them private.
	protected function getDataListClauses() {
		return null;
	}

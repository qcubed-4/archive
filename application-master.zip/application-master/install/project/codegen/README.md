# About `codegen` directory

The codegen-related class in this directory allow you to override 
the functionality of the codegen operation.

Feel free to make any changes to these customizations as you wish.

NOTE: the templates subdirectory is available for you to place customizations to the templates
and subtemplates themselves.  Read the README.md file in templates/ to find out more.

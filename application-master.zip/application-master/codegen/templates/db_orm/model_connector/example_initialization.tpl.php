// Initialize fields with default values from database definition
/*
    public function __construct($objParentObject, <?= $objTable->ClassName ?> $obj<?= $objTable->ClassName ?>)
    {
        parent::__construct($objParentObject,$obj<?= $objTable->ClassName ?>);
        if ( !$this->blnEditMode ){
            $this->obj<?= $objTable->ClassName ?>->Initialize();
        }
    }
*/

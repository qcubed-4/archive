# About `tmp` directory

This directory is used by the Cache object to cache any files for use by the system.

**NOTE**: Please be sure that the webserver service has full read/write/execute privileges for the cache directory.
# About `panel` directory

Panel classes will be saved by the Code Generator here. 

These files will be created by the code generation process only if they do not exist in this directory.

You can modify these files, and they will not be replaced.
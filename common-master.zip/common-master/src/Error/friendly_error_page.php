<?php require(QCUBED_CONFIG_DIR . '/header.inc.php'); ?>

	<h1>Oops!</h1>

	<p>An error has occurred. It has been logged and we'll look into it right away.</p>

	<p><strong>Thanks for your understanding!</strong></p>

<?php require(QCUBED_CONFIG_DIR . '/footer.inc.php'); ?>
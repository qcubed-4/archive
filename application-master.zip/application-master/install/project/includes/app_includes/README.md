# About `app_includes` directory

This directory is where you would have to put all your code. This is the place where you should create new class files for your work. Read the comments in `app_includes.inc.php` to learn more about how you can add classes. Create directories and files here as you wish. You are free to choose your own hierarchy of directories and files in this directory as long as you are sticking with the rules of adding class files to the autoloader.

This is also a safe place to keep all your templates here if you want to.
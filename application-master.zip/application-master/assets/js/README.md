# About `js` directory

JS files useful/necessary for making QCubed framework behave properly reside here. Do not alter/delete any file unless you really need to. 

If you do need to do that, it's probably a bug. Create an issue and let us know.
<?php
/**
 *
 * Part of the QCubed PHP framework.
 *
 * @license MIT
 *
 */

namespace QCubed\Cache\Exception;

class InvalidArgument extends \Exception implements \Psr\SimpleCache\InvalidArgumentException {

}

# About `install` directory

This directory contains the `project` directory which is used by the [app-starter](https://github.com/qcubed-4/app-starter) to initialize the project that you want to build with QCubed-4.

Most of your work, while developing your web-app will be restricted inside the `project` folder only. 

# QCubed-4 Orm
QCubed-4 Standalone ORM

This is for version 4.0 of QCubed, and is pre-alpha at this point

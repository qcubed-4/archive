# About `images` directory

This directory contains the images which make QCubed look well. 

Most probably, you would not need most of these images in your own web-app. 
However, some images are part of QControls within QCubed and must be present.

Do not put your app's images here. Use the image assets directory in the `project` directory instead.
<?php

// Called by the code generator to locate templates

$paths[] =  QCUBED_BASE_DIR . '/application/codegen/templates/';
return $paths;
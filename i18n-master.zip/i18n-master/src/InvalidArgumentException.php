<?php

namespace QCubed\I18n;

use Psr\SimpleCache;


class InvalidArgumentException extends \Exception implements SimpleCache\InvalidArgumentException {

}
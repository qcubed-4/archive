<?php
	require_once('./qcubed.inc.php');
	QImageLabel::Run();

<h3>This is the Panel of Textboxes</h3>
Note how we can use <b>$this</b> in the template to refer to the control, like <b>$this->Form->strMessage</b>:
"<?php _p($this->Form->strMessage); ?>"<br/><br/>
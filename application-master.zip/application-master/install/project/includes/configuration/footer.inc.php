<?php
	// This example footer.inc.php is intended to be modfied for your application.
?>
		</section>
		<footer>
			<div id="tagline"><a href="http://qcubed.github.com/" title="QCubed Homepage"><img id="logo" src="<?= (QCUBED_IMAGE_URL . '/qcubed-4_logo_footer.png'); ?>" alt="QCubed Framework" /> <span class="version"><?= (QCUBED_VERSION); ?></span></a></div>
		</footer>
	</body>
</html>

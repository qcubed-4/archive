# About `images` (cached images) directory

This folder is to store cached images created by custom controls or processes.
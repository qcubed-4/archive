<?php
define ('QCUBED_ORM_TOOLS_URL', QCUBED_BASE_URL . '/orm/tools');
define ('QCUBED_ORM_TOOLS_DIR', QCUBED_BASE_DIR . '/orm/tools');
define ('QCUBED_CODEGEN_URL', QCUBED_ORM_TOOLS_URL . '/codegen.php');

define ('QCUBED_PROJECT_MODEL_DIR', QCUBED_PROJECT_INCLUDES_DIR . '/model' );
define ('QCUBED_PROJECT_MODEL_GEN_DIR', QCUBED_PROJECT_GEN_DIR . '/model_base' );



# About `generated` directory

All files in all subdirectories of the **generated** directory will be replaced every time you do a code generation and hence it is not wise to alter files in this directory manually; unless you are trying to debug and have to tinker around here. 

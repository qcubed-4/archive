<?php

namespace QCubed\Error;

class NullHandler
{
    public static function handleError($errNum, $errStr, $errFile, $errLine)
    {
    }
}

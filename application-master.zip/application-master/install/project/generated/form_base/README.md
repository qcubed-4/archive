# About `form_base` directory

QForm base classes will be saved by the Code Generator here. 

These files will be replaced every time you do a code generation.
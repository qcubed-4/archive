	public function save($blnForceUpdate = false) {
		$this->mct<?= $strPropertyName ?>->save<?= $strPropertyName ?>($blnForceUpdate);
	}

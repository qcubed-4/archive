<?php
// Include prepend.inc to load QCubed
require(dirname(__DIR__) . '/qcubed.inc.php');
		</td>
	</tr>
	<tr>
		<td colspan="10">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td><?php $_CONTROL->dtgRecordsSummary->Render(); ?></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td>
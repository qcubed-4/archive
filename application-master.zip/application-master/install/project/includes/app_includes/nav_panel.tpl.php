<?php
	global $gObjectNamePlural;	// defined in list form template
?>
<h1><?php _t('Listing All'); ?> <?= t($gObjectNamePlural); ?></h1>
<h2><a href="<?= QCUBED_APP_TOOLS_URL ?>/form_drafts.php">&laquo; <?= t('Go to "Forms"'); ?></a></h2>

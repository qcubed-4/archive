# About `php` directory
 
This directory contains files useful for various QCubed controls (QControl) as well as the pages responsible for presenting error messages to the user.
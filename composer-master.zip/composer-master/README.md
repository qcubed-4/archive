# Composer
Support scripts for composer installation of QCubed-4
